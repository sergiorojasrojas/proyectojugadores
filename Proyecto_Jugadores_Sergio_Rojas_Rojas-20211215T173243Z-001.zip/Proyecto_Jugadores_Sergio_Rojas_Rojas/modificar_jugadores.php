<html>
 <head>
 <title>CPTO. INTERAULAS BALONCESTO: "IES JOGUARTS"</title>
 <link rel="stylesheet" type="text/css" href="estilos.css">
 </head>
 <body>
<h2>ACTUALIZAR JUGADORES</h2>
<p></u>Formulario de actualizaci&oacute;n de jugadores.</u><br /><br />
<form action='./insertar_modificar_jugadores.php' method='POST'>
<table border='1' cellspacing='1' cellpadding='0'>
 <tr>
 <th>C&Oacute;DIGO</th>
 <th>NOMBRE</th>
 <th>APELLIDO</th>
 <th>TANTOS</th>
 <th>PUESTO</th>
 <th>CLASE</th>
 </tr>
<?php
/*
* Lo primero es conectarse a la base de datos con el usuario adecuado.
*/
$host = "localhost"; //Variables de usuario para acceder al SGBD
$user = "insertarmodificar";
$pass = "insermod7.";
$db = "BALONCESTO_CANARIAS";
if (!$conx = mysqli_connect($host, $user, $pass, $db)){
die("No se pudo crear la conexi&oacute al SGBD");
}
// Datos de la tabla jugadores
$qry = "SELECT * FROM jugadores ORDER BY nombr ";
$res = mysqli_query($conx, $qry);
for($i=0;$fila=mysqli_fetch_array($res, MYSQLI_ASSOC);$i++){
	/* Informamos la tabla con los datos*/
	
 echo "<tr>";
 echo"<td><input type='hidden' name=\"codigo[$i]\" value='".$fila['codalumno']."' />".$fila['codalumno']."</td>";
 echo"<td><input type='text' name=\"nombre[$i]\" value='".$fila['nombre']."' /></td>";
 echo"<td><input type='text' name=\"apellido[$i]\" value='".$fila['apellido']."' /></td>";
 echo"<td><input type='text' name=\"tantos[$i]\" value='".$fila['tantos_marcados']."' /></td>";
 echo"<td><input type='text' name=\"puesto[$i]\" value='".$fila['puesto']."' /></td>";
 echo"<td><input type='text' name=\"clase[$i]\" value='".$fila['clase']."' /></td>";
 echo "</tr>";
}
mysqli_free_result();
mysqli_close($conx); //Cerramos la conexión

?>
</table>
&nbsp;&nbsp;&nbsp;<input type="submit" name="enviar" value="Modificar"/>
&nbsp;&nbsp;&nbsp;<input type="reset" name="reset" value="Restaurar"/>
</form>
</p>
<p>Todos los campos son obligatorios</p><br /><br />
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="./index.php">Volver al
men&uacute;</a></p>
 </body>
</html>