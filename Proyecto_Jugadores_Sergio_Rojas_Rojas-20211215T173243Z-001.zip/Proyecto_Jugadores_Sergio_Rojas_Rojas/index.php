<html>
 <head>
 <title>CPTO. INTERAULAS BALONCESTO: "IES JOGUARTS"</title>
 <link rel="stylesheet" type="text/css" href="estilos.css">
<script>
<!--código de bienvenida-->
function popup() {
    alert("Hola Mi nombre es Sergio Rojas Rojas: Bienvenido a mi formulario Web C.B BALONCESTO CANARIAS")
}
</script>
 </head>
 <body>
<?php
 if (!empty($_POST)){
$host = "localhost"; //Variables de usuario para acceder al SGBD
$user = "sergio";
$pass = "sergio7.";
$db = "BALONCESTO_CANARIAS";
if (!$conx = mysqli_connect($host, $user, $pass)){
die("No se pudo crear la conexi&oacute al SGBD");
}
/* Si existe la BD la elimino y la creo nueva */
$qry = "DROP DATABASE IF EXISTS ". $db;
mysqli_query($conx, $qry);
$qry = "CREATE DATABASE ". $db;
mysqli_query($conx, $qry);
mysqli_select_db($conx, $db); //selecciono la BD recién creada
/* Creo las tablas de la BD */
$qry = "CREATE TABLE Jugadores(
codalumno char(7) primary key not null,
nombre varchar(20) not null,
apellido varchar(20) not null,
tantos_marcados smallint unsigned default 0,
puesto tinyint unsigned not null,
clase char(3) not null
)";
mysqli_query($conx, $qry);
$qry = "CREATE TABLE Clases(
codigo char(3) primary key not null,
grupo varchar(20) not null,
nombre_tutor varchar(40),
puntuacion int unsigned,
capitan char(7)
)";
mysqli_query($conx, $qry);
$qry = "CREATE TABLE Puestos(
codigo tinyint(3) primary key not null auto_increment,
nombre varchar(10) not null,
descripcion text null
)";
mysqli_query($conx, $qry);
/* Inserto en la BD los valores de las tablas Clases y Puestos */
$qry = 'insert into Clases VALUES ("E1A","1 ESO A","FEDERICO PEREZ",6,"E1A137")';
mysqli_query($conx, $qry);
 $qry = 'insert into Clases VALUES ("E1B","1 ESO B","TERESA CANO",2,"E1B015")';
mysqli_query($conx, $qry);
$qry = 'insert into Clases VALUES ("E2A","2 ESO A","JAVIER GONZALEZ",0,"E2A422")';
mysqli_query($conx, $qry);
$qry = 'insert into Clases VALUES ("E2B","2 ESO B","PATRICIA SANCHEZ",4,"E2B327")';
mysqli_query($conx, $qry);
$qry = 'insert into Puestos set nombre = "BASE"';
mysqli_query($conx, $qry);
$qry = 'insert into Puestos set nombre = "ALERO"';
mysqli_query($conx, $qry);
$qry = 'insert into Puestos set nombre = "ALA-PIVOT"';
mysqli_query($conx, $qry);
$qry = 'insert into Puestos set nombre = "PIVOT"';
mysqli_query($conx, $qry);
$qry = 'insert into Puestos set nombre = "ESCOLTA"';
mysqli_query($conx, $qry);
/* Una vez creada la BD, cierro la conexión.*/
mysqli_close($conx);
echo "<h3><center>La base de datos ".$db." se ha creado correctamente</center></h3><br />";
 }
?>
<h2>MEN&Uacute; DE OPCIONES DEL FORMULARIO DE BALONCESTO_CANARIAS</h2>
<p><b>Opciones:</b></p>
<p>
&nbsp;&nbsp;&nbsp;<a href="./inscripcion_jugadores.php">Insertar nuevos jugadores</a><br /><br />
&nbsp;&nbsp;&nbsp;<a href="./modificar_jugadores.php">Modificar datos jugadores</a><br /><br />
&nbsp;&nbsp;&nbsp;<a href="./mostrar_jugadores.php">Mostrar jugadores inscritos</a><br /><br /><br />
</p>
<p>Pulsando el siguiente bot&oacute;n se genera la BD, eliminando TODOS los datos existentes.<br /><br />
<form action='' method='POST'>
&nbsp;&nbsp;&nbsp;<input type="submit" name="generar" value="Generar BD"/>
</form>
</p>
<div id="cookie-notice" role="banner" class="cn-bottom bootstrap" style="color: #fff; background-color: #000;" 
aria-label="Cookie Notice"><div class="cookie-notice-container"><span id="cn-notice-text">
Utilizamos cookies para asegurar que damos la mejor experiencia al usuario en nuestra web. 
Si sigues utilizando este sitio asumiremos que estás de acuerdo.</span><a href="#" id="cn-accept-cookie"
 data-cookie-set="accept" class="cn-set-cookie cn-button bootstrap button">Vale</a>
 <a href="https://cbcanarias.net/politica-de-cookies/" target="_blank" id="cn-more-info" 
 class="cn-more-info cn-button bootstrap button">Política de cookies</div>
 </body>
</html>