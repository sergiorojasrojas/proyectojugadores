<html>
 <head>
 <title>CPTO. INTERAULAS BALONCESTO: "IES JOGUARTS"</title>
 <link rel="stylesheet" type="text/css" href="estilos.css">
 </head>
 <body>
<h2>CONSULTAR JUGADORES</h2>
<p></u>Listado de jugadores por equipo</u><br /><br />
<table border='1' cellspacing='1' cellpadding='0'>
 <tr>
 <th>C&Oacute;DIGO</th>
 <th>NOMBRE</th>
 <th>APELLIDO</th>
 <th>TANTOS</th>
 <th>PUESTO</th>
 <th>CLASE</th>
 </tr>
<?php
/*
* Lo primero es conectarse a la base de datos con el usuario adecuado.
*/
$host = "localhost"; //Variables de usuario para acceder al SGBD
$user = "consultar";
$pass = "consultar7.";
$db = "BALONCESTO_CANARIAS";
if (!$conx = mysqli_connect($host, $user, $pass, $db)){
die("No se pudo crear la conexi&oacute al SGBD");
}
// Datos de la tabla jugadores
$qry = "SELECT * FROM jugadores ORDER BY clase ";
$res = mysqli_query($conx, $qry);
while($fila = mysqli_fetch_array($res, MYSQLI_ASSOC)){ 

// Informamos la tabla con los datos
 ?>
 <tr>
<td><?php echo $fila['codalumno']; ?></td>
<td><?php echo $fila['nombre']; ?></td>
<td><?php echo $fila['apellido']; ?></td>
<td><?php echo $fila['tantos_marcados']; ?></td>
<td><?php echo $fila['puesto']; ?></td>
<td><?php echo $fila['clase']; ?></td>
 </tr>

<?php
}

mysqli_close($conx); //Cerramos la conexión

?>
</table>
</p><br /><br />
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="./index.php">Volver al
men&uacute;</a></p>
 </body>
</html>