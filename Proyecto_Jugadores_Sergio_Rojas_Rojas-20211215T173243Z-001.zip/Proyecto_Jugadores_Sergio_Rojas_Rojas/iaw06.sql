/*
   REGLAS DE INTEGRIDAD
   ====================
   Jugadores se relaciona con Clases: Jugadores.clase -> Clases.codigo
   y con Puestos: Jugadores.puesto -> Puestos.codigo
   
   No se han creado las Foreign Key.
*/

use Baloncesto;

/* Las clases no pueden tener otro valor que no esté en esta relación */

insert into clases VALUES ("E1A","1 ESO A","FEDERICO PEREZ",6,"E1A137"),
                          ("E1B","1 ESO B","TERESA CANO",2,"E1B015"),
			  ("E2A","2 ESO A","JAVIER GONZALEZ",0,"E2A422"),
			  ("E2B","2 ESO B","PATRICIA SANCHEZ",4,"E2B327");

/* Los puestos no pueden tener otro valor que no esté en esta relación */

insert into puestos set nombre = "BASE";   
insert into puestos set nombre = "ALERO";    
insert into puestos set nombre = "ALA-PIVOT";
insert into puestos set nombre = "PIVOT";   
insert into puestos set nombre = "ESCOLTA";   