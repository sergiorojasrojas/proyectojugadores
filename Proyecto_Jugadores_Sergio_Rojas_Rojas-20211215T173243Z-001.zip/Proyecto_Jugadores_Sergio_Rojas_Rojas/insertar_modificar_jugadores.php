<?php
/*
* Este fichero procesará las peticiones realizadas por los formularios de inserción y modificación de jugadores.
*
* El valor de la variable enviar de $_POST solo puede tomar dos valores: Insertar o Modificar
*/
// Creamos la conexión a la BD con el usuario apropiado.
$host = "localhost"; //Variables de usuario para acceder al SGBD
$user = "insertarmodificar";
$pass = "insermod7.";
$db = "BALONCESTO_CANARIAS";
if (!$conx = mysqli_connect($host, $user, $pass, $db)){
die("No se pudo crear la conexi&oacute al SGBD");
}
if ($_POST["enviar"] == "Insertar"){ // Estamos insertando datos
$qry = "INSERT INTO jugadores VALUES('".$_POST['codigo']."',
'".$_POST['nombre']."',
'".$_POST['apellido']."',0,
".$_POST['puesto'].",
'".$_POST['clase']."')";
if (!mysqli_query($conx,$qry)){
$mensaje = "Se ha producido un error al insertar los datos.";
printf("<br>\nError: %s\n", mysqli_sqlstate($conx));
printf("<br>\nError: %s\n", mysqli_error($conx));
printf("<br>\nError: %d\n", mysqli_error($conx));
}
else{
$mensaje = "Se han insertado los datos correctamente.";
}
}
else{ // Estamos modificando datos
$n = sizeof($_POST['codigo']); // $_POST va a ser un array de arrays.
$fallo = 0; // Si se produce un error en una modificación no saca el mensaje de OK
for($i = 0; $i < $n; $i++){
$qry = "UPDATE jugadores SET
nombre = '".$_POST['nombre'][$i]."', apellido = '".$_POST['apellido'][$i]."',
tantos_marcados = ".$_POST['tantos'][$i].", puesto = ".$_POST['puesto'][$i].",
clase = '".$_POST['clase'][$i]."'
WHERE codalumno = '".$_POST['codigo'][$i]."'";
if (!mysqli_query($conx,$qry)){
$fallo = 1;
echo "Se ha producido un error al modificar los datos de la fila: ".$i.".<br>\n";
printf("<br>\nError: %s\n", mysqli_sqlstate($conx));
printf("<br>\nError: %s\n", mysqli_error($conx));
printf("<br>\nError: %d<br>\n", mysqli_error($conx));
} // End IF
} // End Bucle FOR
if($fallo == 0){
$mensaje = "Se han modificado los datos correctamente.";
}
} // FIN del IF externo
mysqli_close($conx);
?>
<html>
 <head>
 <title>CAMPEONATO LIGA ACB: "C.B BALONCESTO CANARIAS"</title>
 <link rel="stylesheet" type="text/css" href="estilos.css">
 </head>
 <body>
<h2><center><?php echo $mensaje;?></center></h2>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="./index.php">Volver al
men&uacute;</a></p>
 </body></html>