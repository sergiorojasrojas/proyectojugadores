<html>
 <head>
 <title>CPTO. INTERAULAS BALONCESTO: "IES JOGUARTS"</title>
 <link rel="stylesheet" type="text/css" href="estilos.css">
 </head>
 <body>
<h2>INSERTAR JUGADORES</h2>
<p></u>Formulario de inscripci&oacute;n de jugadores BALONCESTO_CANARIAS</u><br /><br />
<form action='./insertar_modificar_jugadores.php' method='POST'>
C&Oacute;DIGO:&nbsp;<input type="text" name="codigo" /><br />
NOMBRE:&nbsp;<input type="text" name="nombre" /><br />
APELLIDO:&nbsp;<input type="text" name="apellido" /><br />
PUESTO:&nbsp;<select name="puesto">
<option value="NULL"> -- Escoja un valor -- </option>;
<?php
/*
* Vamos a acceder a las tablas para recuperar los datos ya insertados para Puestos y Clases
*
* Lo primero es conectarse a la base de datos con el usuario adecuado.
*/
$host = "localhost"; //Variables de usuario para acceder al SGBD
$user = "consultar";
$pass = "consultar7.";
$db = "BALONCESTO_CANARIAS";
if (!$conx = mysqli_connect($host, $user, $pass, $db)){
die("No se pudo crear la conexi&oacute al SGBD");
}
$qry = "SELECT codigo, nombre FROM puestos";
$res = mysqli_query($conx, $qry);
/*
* Procesamos los datos recuperados para informar la select-option.
* Empleamos MYSQLI_ASSOC porque usamos los nombres de las columnas
*/
while($fila = mysqli_fetch_array($res, MYSQLI_ASSOC)){
echo "<option value=".$fila['codigo'].">".$fila['nombre']."</option>";
}
mysqli_free_result(); //Debemos liberar el espacio
?>
</select><br />
CLASE:&nbsp;<select name="clase">
<option value="NULL"> -- Escoja un valor -- </option>;
<?php
/*
* Ya tenemos la conexión creada, porque no la hemos cerrado.
* Procesamos los datos recuperados para informar 2ª la select-option.
*/
$qry = "SELECT codigo, grupo FROM clases";
$res = mysqli_query($conx, $qry);
while($fila = mysqli_fetch_array($res, MYSQLI_ASSOC)){
echo "<option value=".$fila['codigo'].">".$fila['grupo']."</option>";
}
mysqli_free_result(); //Debemos liberar el espacio
mysqli_close($conx); //Cerramos la conexión
?>
</select><br /><br />
&nbsp;&nbsp;&nbsp;<input type="submit" name="enviar" value="Insertar"/>
&nbsp;&nbsp;&nbsp;<input type="reset" name="reset" value="Restaurar"/>
</form>
</p>
<p>Todos los campos son obligatorios</p><br /><br />
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="./index.php">Volver al
men&uacute;</a></p>
 </body></html>